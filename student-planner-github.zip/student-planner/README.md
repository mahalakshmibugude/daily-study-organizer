# Student Planner

A simple student planner made with **HTML, CSS and JavaScript**. It is suitable as a beginner / first-year student GitHub project.

## Features
- Add a study task with a subject and due date
- Mark tasks as completed
- Delete tasks
- Filter all, pending and completed tasks
- See total, completed and pending task counts
- Save tasks in browser `localStorage`, so they remain after refreshing

## How to run
1. Download or clone this repository.
2. Open the project folder.
3. Double-click `index.html` or open it in a browser.
4. Add your study tasks.

No installation is required.

## Files
- `index.html` — page structure
- `style.css` — design and responsive layout
- `script.js` — task functions and local storage

## GitHub upload
Create a new repository named `student-planner`, then upload these four files (or upload the ZIP contents). Add a short description such as: `A beginner-friendly student planner using HTML, CSS and JavaScript.`
