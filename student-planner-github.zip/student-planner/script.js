const taskForm = document.getElementById("taskForm");
const taskTitle = document.getElementById("taskTitle");
const subjectInput = document.getElementById("subject");
const dueDateInput = document.getElementById("dueDate");
const taskList = document.getElementById("taskList");
const emptyMessage = document.getElementById("emptyMessage");
const filterSelect = document.getElementById("filter");

let tasks = JSON.parse(localStorage.getItem("studentPlannerTasks") || "[]");

document.getElementById("today").textContent =
  new Date().toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });

function saveTasks() {
  localStorage.setItem("studentPlannerTasks", JSON.stringify(tasks));
}

function renderTasks() {
  const filter = filterSelect.value;
  const visibleTasks = tasks.filter(task => {
    if (filter === "pending") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  taskList.innerHTML = "";
  emptyMessage.hidden = visibleTasks.length > 0;

  visibleTasks.forEach(task => {
    const item = document.createElement("article");
    item.className = `task${task.completed ? " done" : ""}`;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = task.completed;
    checkbox.setAttribute("aria-label", `Mark ${task.title} as completed`);
    checkbox.addEventListener("change", () => {
      task.completed = checkbox.checked;
      saveTasks();
      renderTasks();
    });

    const info = document.createElement("div");
    info.className = "task-info";
    const title = document.createElement("strong");
    title.textContent = task.title;
    const details = document.createElement("small");
    details.textContent = `${task.subject || "General"} · Due: ${task.dueDate}`;
    info.append(title, details);

    const removeButton = document.createElement("button");
    removeButton.className = "delete";
    removeButton.textContent = "Delete";
    removeButton.setAttribute("aria-label", `Delete ${task.title}`);
    removeButton.addEventListener("click", () => {
      tasks = tasks.filter(current => current.id !== task.id);
      saveTasks();
      renderTasks();
    });

    item.append(checkbox, info, removeButton);
    taskList.appendChild(item);
  });

  document.getElementById("totalCount").textContent = tasks.length;
  document.getElementById("completedCount").textContent = tasks.filter(t => t.completed).length;
  document.getElementById("pendingCount").textContent = tasks.filter(t => !t.completed).length;
}

taskForm.addEventListener("submit", event => {
  event.preventDefault();
  const title = taskTitle.value.trim();
  const dueDate = dueDateInput.value;
  if (!title || !dueDate) return;

  tasks.unshift({
    id: Date.now(),
    title,
    subject: subjectInput.value.trim(),
    dueDate,
    completed: false
  });

  saveTasks();
  taskForm.reset();
  taskTitle.focus();
  renderTasks();
});

filterSelect.addEventListener("change", renderTasks);
renderTasks();
